# Flappy-bird-python
A basic Flappy Bird game made in Python

I took the assets from https://github.com/zhaolingzhi/FlapPyBird-master | Credits to him

## Current State:
![Screenshot](https://github.com/LeonMarqs/Flappy-bird-python/blob/master/Screenshot_1.png)

## Dependence:
* pygame

## Contribution
It's a simple model, so I'd be very grateful if you could help me to improve the game.



